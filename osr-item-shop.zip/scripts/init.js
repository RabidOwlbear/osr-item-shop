
import {registerHooks} from "./hooks.mjs"

registerHooks()









